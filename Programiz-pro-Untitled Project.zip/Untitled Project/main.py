dict = { 'hello':4, 'every':3, 'one':2} 
tuplelist =  list(dict.items())
print(tuplelist)